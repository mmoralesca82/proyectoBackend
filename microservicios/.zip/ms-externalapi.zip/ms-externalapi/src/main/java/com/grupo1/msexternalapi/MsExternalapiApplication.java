package com.grupo1.msexternalapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsExternalapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsExternalapiApplication.class, args);
	}

}
