package com.grupo1.msexternalapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsExternalapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
