package com.grupo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsLaboratorioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsLaboratorioApplication.class, args);
	}

}
