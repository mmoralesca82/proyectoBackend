package com.grupo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMedicinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
